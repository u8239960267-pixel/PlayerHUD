package pl.playerhud;

public class HudConfig {
    public static boolean isEnabled = true;
    public static boolean showSkin = true;
    public static boolean showHearts = true;
    public static boolean showArmor = true;
    
    // Początkowa domyślna pozycja HUD na Twoim monitorze
    public static int hudX = 30;
    public static int hudY = 30;
}
